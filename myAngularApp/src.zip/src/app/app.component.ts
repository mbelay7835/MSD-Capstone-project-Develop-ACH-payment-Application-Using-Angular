import { Component } from '@angular/core';
import axios from 'axios';
import * as braintree from 'braintree-web';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  constructor() { }

  token: any;
  nounce:any;

  ngOnInit() {
    axios.get(`http://localhost:3000/api/v1/token`)
      .then((response: any) => {
        console.log(response)
        this.token = response.data.token
        localStorage.setItem("token", response.data.token)
      })
      .catch(error => {
        console.log(error)
      })
  }

  async createBraintree() {
    this.nounce =  await braintree.client.create({
      authorization: this.token
    }, function (clientErr: any, clientInstance: any) {
      if (clientErr) {
        console.error('There was an error creating the Client.');
        throw clientErr;
      }
      
      console.log(clientInstance)
      braintree.usBankAccount.create({
        client: clientInstance
      }, function (usBankAccountErr: any, usBankAccountInstance: any) {
        if (usBankAccountErr) {
          console.error('There was an error creating the USBankAccount instance.');
          throw usBankAccountErr;
        }
        console.log(usBankAccountInstance)
        // Use the usBankAccountInstance here.
        var bankDetails: any = {
          accountNumber: "1000000000",
          routingNumber: "011000015",
          accountType: "checking",
          ownershipType: "personal",
          billingAddress: {
            streetAddress: "9521 saluda Ct",
            extendedAddress: "",
            locality: "",
            region: "",
            postalCode: "22079"
          }
        };

        if (bankDetails.ownershipType === 'personal') {
          bankDetails.firstName = "Mequanint";
          bankDetails.lastName = "Belay";
        } else {
          bankDetails.businessName = "";
        }


      });
    });


    console.log(this.nounce)
  }


sendBraintree(){
  //const nounce = this.createBraintree()
  
  axios.post(`http://localhost:3000/api/v1/checkout`,this.nounce)
     .then((result: any) => {
       //console.log(this.nounce)
        console.log(result)
      }).catch(err=>{
      console.log(err)
    })
}
 

  title = 'myAngularApp';
}
